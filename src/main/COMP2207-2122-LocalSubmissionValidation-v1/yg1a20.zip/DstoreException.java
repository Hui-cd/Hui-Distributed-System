public class DstoreException extends Exception {
    public DstoreException(String message) {
        super(message);
    }
}
