public class FileIndexException extends Exception {
    public FileIndexException(String message) {
        super(message);
    }
}
